		quantos = 0;
		$(document).ready(function(){
			$('#divconfig > a > div').hide();
			$('#divconfig > div:nth-child(1)').click(function(){
				if($('#divconfig > a > div').css('pointer-events')=="none"){
					$('#divconfig > a > div').show();
					$('#divconfig > a > div').css('boxShadow','0px 0px 50px 0px rgba(82, 63, 105, 0.15)');
					$('#divconfig > a > div').css('backgroundColor','white');
					$('#divconfig > a > div').css('color','#6c757d');
					$('#divconfig > a > div').css('transform','translateY(0px)');
					$('#divconfig > a > div').css('pointer-events','auto');
				}else{
					$('#divconfig > a > div').css('boxShadow','none');
					$('#divconfig > a > div').css('backgroundColor','transparent');
					$('#divconfig > a > div').css('color','transparent');
					$('#divconfig > a > div').css('transform','translateY(10px)');
					$('#divconfig > a > div').css('pointer-events','none');
					$('#divconfig > a > div').hide();
				}
			});
		});
		function mostrarul(x){
			if($('#div1 > ul > li:nth-child('+x+') ul li').css('pointer-events')=="auto"){
				quantos--;
				for(y=x+1; y<=10; y++){
					$('#div1 > ul > li:nth-child('+(y)+')').css('transform','translateY(0px)');
					$('#div1 > ul > li:nth-child('+(y)+')').css('transition','0.3s');
				}
				$('#div1 > ul > li:nth-child('+x+') ul li').css('color','transparent');
				$('#div1 > ul > li:nth-child('+x+') ul li').css('pointer-events','none');
				$('#div1 > ul > li:nth-child('+x+')').css('color','rgba(255,255,255,.65)');
				$('#div1 > ul > li:nth-child('+x+') i:nth-child(2)').css('transform','rotate(0deg)');
				$('#div1 > ul > li:nth-child('+x+') i:nth-child(2)').css('transition','0.2s');
			}else{
				quantos++;
				for(y=4; y<=10; y++){
					if($('#div1 > ul > li:nth-child('+y+') ul li').css('pointer-events')=="auto"){
						for(z=y+1; z<=10; z++){
							$('#div1 > ul > li:nth-child('+(z)+')').css('transform','translateY(0px)');
							$('#div1 > ul > li:nth-child('+(z)+')').css('transition','0.3s');
						}
						$('#div1 > ul > li:nth-child('+y+') ul li').css('color','transparent');
						$('#div1 > ul > li:nth-child('+y+') ul li').css('pointer-events','none');
						$('#div1 > ul > li:nth-child('+y+')').css('color','rgba(255,255,255,.65)');
						$('#div1 > ul > li:nth-child('+y+') i:nth-child(2)').css('transform','rotate(0deg)');
						$('#div1 > ul > li:nth-child('+y+') i:nth-child(2)').css('transition','0.2s');
					}
				}
				down = $('#div1 > ul > li:nth-child('+x+') ul li').length;
				for(y=x+1; y<=10; y++){
					$('#div1 > ul > li:nth-child('+(y)+')').css('transform','translateY('+(down*40)+'px)');
					$('#div1 > ul > li:nth-child('+(y)+')').css('transition','0.3s');
				}
				$('#div1 > ul > li:nth-child('+x+') ul li').css('color','rgba(255,255,255,.65)');
				$('#div1 > ul > li:nth-child('+x+') ul li').css('pointer-events','auto');
				$('#div1 > ul > li:nth-child('+x+')').css('color','white');
				$('#div1 > ul > li:nth-child('+x+') i:nth-child(2)').css('transform','rotate(90deg)');
				$('#div1 > ul > li:nth-child('+x+') i:nth-child(2)').css('transition','0.2s');
			}
		}